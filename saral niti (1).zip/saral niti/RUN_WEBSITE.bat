@echo off
title Saral Niti - Server & Public Link Launcher
color 0A
cls
echo ========================================================
echo             SARAL NITI - PORTAL LAUNCHER
echo ========================================================
echo.
echo [1/2] Starting Flask Web Server (Port 5000)...
cd /d "%~dp0frontend"
start "Saral Niti Flask Server" /min python app.py

echo Waiting for server to initialize...
timeout /t 3 /nobreak >nul

echo.
echo [2/2] Opening Local Website in Browser...
start http://127.0.0.1:5000

echo.
echo ========================================================
echo   Local URL:       http://127.0.0.1:5000
echo   Same Wi-Fi URL:  http://10.16.165.145:5000
echo ========================================================
echo.
echo Starting Cloudflare Public Tunnel...
echo (Keep this window OPEN as long as you want the link to work)
echo.

if exist "C:\Users\prash\cloudflared.exe" (
    "C:\Users\prash\cloudflared.exe" tunnel --url http://127.0.0.1:5000
) else (
    echo Cloudflared not found at C:\Users\prash\cloudflared.exe
    echo Please make sure cloudflared.exe exists.
    pause
)
